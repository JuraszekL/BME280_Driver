var structBME280__Config__t =
[
    [ "filter", "structBME280__Config__t.html#af095fd502def890a8e98d193bcb3d749", null ],
    [ "mode", "structBME280__Config__t.html#ab1ac0daa2bed99e25261cd36290b5d27", null ],
    [ "oversampling_h", "structBME280__Config__t.html#aa8cd08834e59ff14394adfa05cb06d15", null ],
    [ "oversampling_p", "structBME280__Config__t.html#a55118fc936ebcc370e147359340f2b73", null ],
    [ "oversampling_t", "structBME280__Config__t.html#a291f3b47c3ea9eb3d99cde5684c66790", null ],
    [ "spi3w_enable", "structBME280__Config__t.html#a4b8181813d6fb586286ab0e717eeb855", null ],
    [ "t_stby", "structBME280__Config__t.html#a64ecf8b298a66dec8eb97e16c579810b", null ]
];