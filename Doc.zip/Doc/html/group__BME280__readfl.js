var group__BME280__readfl =
[
    [ "Read in normal mode", "group__BME280__readnormalmodef.html", "group__BME280__readnormalmodef" ],
    [ "Read in forced mode", "group__BME280__readforcedmodef.html", "group__BME280__readforcedmodef" ]
];