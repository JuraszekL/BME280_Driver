var group__BME280__Regs =
[
    [ "BME280_CALIB_DATA1_ADDR", "group__BME280__Regs.html#ga1998de0e5c668bb766c3eb4d7875a566", null ],
    [ "BME280_CALIB_DATA1_LEN", "group__BME280__Regs.html#ga4dcce354323a4dbf34f3ef1ba80e4857", null ],
    [ "BME280_CALIB_DATA2_ADDR", "group__BME280__Regs.html#ga9907b9a239b463a2ef190f646c77d1f3", null ],
    [ "BME280_CALIB_DATA2_LEN", "group__BME280__Regs.html#ga38f52d57e8cee049ca04dabf609c5093", null ],
    [ "BME280_CONFIG_ADDR", "group__BME280__Regs.html#ga7c2fa57fdeb63ca2c255432f4c98298e", null ],
    [ "BME280_CTRL_HUM_ADDR", "group__BME280__Regs.html#ga8f090989bb45d85c2605e4a86a49b46d", null ],
    [ "BME280_CTRL_MEAS_ADDR", "group__BME280__Regs.html#ga53b7ccb8b940a9bdd861a7722732c9cc", null ],
    [ "BME280_HUM_ADC_ADDR", "group__BME280__Regs.html#ga772b91958d526d445888ee53f7e114c0", null ],
    [ "BME280_HUM_ADC_LEN", "group__BME280__Regs.html#gad0c15a4ff8af9144b469e9afb0084ace", null ],
    [ "BME280_ID", "group__BME280__Regs.html#ga9aa1e714b7260f21de419112f041aad7", null ],
    [ "BME280_ID_ADDR", "group__BME280__Regs.html#ga85a99a959b992d5626f3b6d38e64a075", null ],
    [ "BME280_PRESS_ADC_ADDR", "group__BME280__Regs.html#gad4e055d48eb4c21fc7ba15b295b99e91", null ],
    [ "BME280_PRESS_ADC_LEN", "group__BME280__Regs.html#ga17560836f0bdd37445cb83c88a0db309", null ],
    [ "BME280_RESET_ADDR", "group__BME280__Regs.html#ga946f939c2dda53735f06cb86abb216e4", null ],
    [ "BME280_RESET_VALUE", "group__BME280__Regs.html#ga9e92d26970e0f357fed2f1bc13f86950", null ],
    [ "BME280_STATUS_ADDR", "group__BME280__Regs.html#ga4c24f9719642803fe7ea624ba487645b", null ],
    [ "BME280_TEMP_ADC_ADDR", "group__BME280__Regs.html#gaac341b4b1687973bb08cafbc04895860", null ],
    [ "BME280_TEMP_ADC_LEN", "group__BME280__Regs.html#ga09c012db6165503a3986214dff56d777", null ]
];