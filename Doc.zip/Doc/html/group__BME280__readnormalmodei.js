var group__BME280__readnormalmodei =
[
    [ "BME280_ReadAllLast", "group__BME280__readnormalmodei.html#ga5a1fa42b116bd05996150dbcfba7dc16", null ],
    [ "BME280_ReadHumLast", "group__BME280__readnormalmodei.html#gaa5e0c9fd51a768a9113ed0405fd053be", null ],
    [ "BME280_ReadPressLast", "group__BME280__readnormalmodei.html#gae418270b344349371f7dfb0736556dbf", null ],
    [ "BME280_ReadTempLast", "group__BME280__readnormalmodei.html#ga72cfa00fad7c88ba8fd4e5b4f3085a45", null ]
];