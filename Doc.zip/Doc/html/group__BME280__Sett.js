var group__BME280__Sett =
[
    [ "Oversampling", "group__BME280__Ovs.html", "group__BME280__Ovs" ],
    [ "Operating Mode", "group__BME280__mode.html", "group__BME280__mode" ],
    [ "Standby Time", "group__BME280__tstby.html", "group__BME280__tstby" ],
    [ "IIR Filter", "group__BME280__filter.html", "group__BME280__filter" ]
];