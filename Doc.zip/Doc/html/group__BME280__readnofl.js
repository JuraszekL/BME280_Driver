var group__BME280__readnofl =
[
    [ "Read in normal mode", "group__BME280__readnormalmodei.html", "group__BME280__readnormalmodei" ],
    [ "Read in forced mode", "group__BME280__readforcedmodei.html", "group__BME280__readforcedmodei" ]
];