var group__BME280__Ret =
[
    [ "BME280_BUSY_ERR", "group__BME280__Ret.html#ga32e5db18d3a7e0b757149f17e769202a", null ],
    [ "BME280_CONDITION_ERR", "group__BME280__Ret.html#ga14ce72f1502c0a552269f77e0e35ff44", null ],
    [ "BME280_ID_ERR", "group__BME280__Ret.html#gac2ba5cf36e4e6d585f2e0292a150f37f", null ],
    [ "BME280_INTERFACE_ERR", "group__BME280__Ret.html#gab907098505f6b6ac522e21d927e62962", null ],
    [ "BME280_NO_INIT_ERR", "group__BME280__Ret.html#ga848a61967bf8cea667065de6bb42fdc1", null ],
    [ "BME280_OK", "group__BME280__Ret.html#gabfe3dd12ee6f5f5d51fbb340a22ff678", null ],
    [ "BME280_PARAM_ERR", "group__BME280__Ret.html#ga44bac1807067bdb83a1f4e40cc715b85", null ]
];