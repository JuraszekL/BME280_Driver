var files_dup =
[
    [ "bme280.c", "bme280_8c.html", "bme280_8c" ],
    [ "bme280.h", "bme280_8h.html", "bme280_8h" ],
    [ "bme280_definitions.h", "bme280__definitions_8h.html", "bme280__definitions_8h" ]
];