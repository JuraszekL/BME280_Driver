var group__BME280__prots =
[
    [ "bme280_delayms", "group__BME280__prots.html#ga53e2f01b2fff79561c1548da10bd2042", null ],
    [ "bme280_readregisters", "group__BME280__prots.html#ga32cf351e23309e871a4efbdca56db043", null ],
    [ "bme280_writeregister", "group__BME280__prots.html#ga0c986cd0bb56d3ab947d36a1ae43411f", null ]
];