var group__BME280__prots =
[
    [ "bme280_delayms", "group__BME280__prots.html#ga53e2f01b2fff79561c1548da10bd2042", null ],
    [ "bme280_readbytes", "group__BME280__prots.html#ga118d97987d70651dc4f04647e3976eb3", null ],
    [ "bme280_writebyte", "group__BME280__prots.html#ga7c71502b5222452a999790497f860309", null ]
];