var group__BME280__readnormalmodef =
[
    [ "BME280_ReadAllLast_F", "group__BME280__readnormalmodef.html#ga02e9364d7737a3ee1565ac00597981c5", null ],
    [ "BME280_ReadHumLast_F", "group__BME280__readnormalmodef.html#gaadd4533f9c6ace8308b547f6dbf4368c", null ],
    [ "BME280_ReadPressLast_F", "group__BME280__readnormalmodef.html#ga72ea87ce22b089ba8bfb3580f5c81f70", null ],
    [ "BME280_ReadTempLast_F", "group__BME280__readnormalmodef.html#gacf484ccb5aa2b3f35746c9c44500668b", null ]
];