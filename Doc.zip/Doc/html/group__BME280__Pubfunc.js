var group__BME280__Pubfunc =
[
    [ "Get Functions", "group__BME280__getfunctions.html", "group__BME280__getfunctions" ],
    [ "Set Functions", "group__BME280__setfunctions.html", "group__BME280__setfunctions" ],
    [ "Read Functions (int)", "group__BME280__readnofl.html", "group__BME280__readnofl" ],
    [ "Read Functions (float)", "group__BME280__readfl.html", "group__BME280__readfl" ],
    [ "BME280_ConfigureAll", "group__BME280__Pubfunc.html#ga234d9a634cbc6f19a39847602646ff56", null ],
    [ "BME280_Init", "group__BME280__Pubfunc.html#ga9bf9479f5ed6d4d9c805fb3dcd660410", null ],
    [ "BME280_Reset", "group__BME280__Pubfunc.html#ga68389bbf482aff0ca3679e80a1161a8a", null ]
];