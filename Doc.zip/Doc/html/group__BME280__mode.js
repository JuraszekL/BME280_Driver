var group__BME280__mode =
[
    [ "BME280_FORCEDMODE", "group__BME280__mode.html#ga29c34119aa7b79a1a5a50ffae3c8bd83", null ],
    [ "BME280_NORMALMODE", "group__BME280__mode.html#ga2e2d6a1e2969b4b54f79fab9315dff9e", null ],
    [ "BME280_SLEEPMODE", "group__BME280__mode.html#gabc5980c14102fd09df9fc7e0fb6275ea", null ]
];