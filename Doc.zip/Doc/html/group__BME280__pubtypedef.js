var group__BME280__pubtypedef =
[
    [ "BME280_S32_t", "group__BME280__pubtypedef.html#gae70d7f84cd968247f7b090605860575f", null ],
    [ "BME280_S64_t", "group__BME280__pubtypedef.html#ga8ce132d31d34bed9f1878ac34e44c5b7", null ],
    [ "BME280_U32_t", "group__BME280__pubtypedef.html#gaabb6320b11fe7353c3151d2ad006f5b4", null ]
];