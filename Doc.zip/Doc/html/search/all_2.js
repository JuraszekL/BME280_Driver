var searchData=
[
  ['cat_5fi16t_123',['CAT_I16T',['../group__BME280__privmacros.html#gaa07db27986139547fe5ffa8788bb1fad',1,'bme280.c']]],
  ['cat_5fui16t_124',['CAT_UI16T',['../group__BME280__privmacros.html#ga356eefd8f88f8cb61866de6dcf4aa6b1',1,'bme280.c']]]
];
