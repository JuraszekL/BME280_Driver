var searchData=
[
  ['operating_20mode_144',['Operating Mode',['../group__BME280__mode.html',1,'']]],
  ['oversampling_145',['Oversampling',['../group__BME280__Ovs.html',1,'']]],
  ['oversampling_5fh_146',['oversampling_h',['../structBME280__Config__t.html#aa8cd08834e59ff14394adfa05cb06d15',1,'BME280_Config_t']]],
  ['oversampling_5fp_147',['oversampling_p',['../structBME280__Config__t.html#a55118fc936ebcc370e147359340f2b73',1,'BME280_Config_t']]],
  ['oversampling_5ft_148',['oversampling_t',['../structBME280__Config__t.html#a291f3b47c3ea9eb3d99cde5684c66790',1,'BME280_Config_t']]]
];
