var searchData=
[
  ['adc_5fregs_0',['adc_regs',['../structadc__regs.html',1,'']]]
];
