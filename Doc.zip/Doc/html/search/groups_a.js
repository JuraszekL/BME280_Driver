var searchData=
[
  ['set_20functions_296',['Set Functions',['../group__BME280__setfunctions.html',1,'']]],
  ['standby_20time_297',['Standby Time',['../group__BME280__tstby.html',1,'']]]
];
