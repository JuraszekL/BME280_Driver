var indexSectionsWithContent =
{
  0: "abcdefghilmoprstuw",
  1: "ab",
  2: "b",
  3: "b",
  4: "defhimoprstw",
  5: "b",
  6: "befgilmoprs",
  7: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Modules",
  7: "Pages"
};

