var searchData=
[
  ['operating_20mode_287',['Operating Mode',['../group__BME280__mode.html',1,'']]],
  ['oversampling_288',['Oversampling',['../group__BME280__Ovs.html',1,'']]]
];
