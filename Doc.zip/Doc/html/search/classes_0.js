var searchData=
[
  ['adc_5fregs_179',['adc_regs',['../structadc__regs.html',1,'']]]
];
