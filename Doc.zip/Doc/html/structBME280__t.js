var structBME280__t =
[
    [ "driver", "structBME280__t.html#a10bb5d73c32e96fa99f59cac8400b41a", null ],
    [ "initialized", "structBME280__t.html#a2f65444a854390d5d5d519e37c84bdc5", null ],
    [ "mode", "structBME280__t.html#afff1f6899ad1250df0946bfcf4aafd8a", null ],
    [ "t_fine", "structBME280__t.html#a8cf3493653572b1200c2c665c5508f2c", null ],
    [ "trimm", "structBME280__t.html#ae335ecac6a9042e547b28590e69a17d0", null ]
];