var annotated_dup =
[
    [ "adc_regs", "structadc__regs.html", "structadc__regs" ],
    [ "BME280_calibration_data", "structBME280__calibration__data.html", "structBME280__calibration__data" ],
    [ "BME280_Config_t", "structBME280__Config__t.html", "structBME280__Config__t" ],
    [ "BME280_Data_t", "structBME280__Data__t.html", "structBME280__Data__t" ],
    [ "BME280_DataF_t", "structBME280__DataF__t.html", "structBME280__DataF__t" ],
    [ "BME280_Driver_t", "structBME280__Driver__t.html", "structBME280__Driver__t" ],
    [ "BME280_t", "structBME280__t.html", "structBME280__t" ]
];