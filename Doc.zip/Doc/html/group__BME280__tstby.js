var group__BME280__tstby =
[
    [ "BME280_STBY_0_5MS", "group__BME280__tstby.html#ga0f2a085489e7d0fa810deca4e27f485d", null ],
    [ "BME280_STBY_1000MS", "group__BME280__tstby.html#ga8ec7f85a06753df72fdd37b8e4a67e0b", null ],
    [ "BME280_STBY_10MS", "group__BME280__tstby.html#ga57ee4040cdbc5ba4b5226180288c129d", null ],
    [ "BME280_STBY_125MS", "group__BME280__tstby.html#gacff2d91f7c5511ac5a2570cb8e6baf3c", null ],
    [ "BME280_STBY_20MS", "group__BME280__tstby.html#ga2f68a77938ba650d1b4f33441b33abfa", null ],
    [ "BME280_STBY_250MS", "group__BME280__tstby.html#ga2e58c7ded56f5dc61da66fc87d03ce6b", null ],
    [ "BME280_STBY_500MS", "group__BME280__tstby.html#ga579a3c422268ee934cfbc3eb371d7652", null ],
    [ "BME280_STBY_62_5MS", "group__BME280__tstby.html#ga0cbc19a4375baac358ace100965ed066", null ]
];