var group__BME280__privmacros =
[
    [ "CAT_I16T", "group__BME280__privmacros.html#gaa07db27986139547fe5ffa8788bb1fad", null ],
    [ "CAT_UI16T", "group__BME280__privmacros.html#ga356eefd8f88f8cb61866de6dcf4aa6b1", null ],
    [ "IS_NULL", "group__BME280__privmacros.html#ga8f310f2fe10ad8a2c5c49e10294827d6", null ]
];