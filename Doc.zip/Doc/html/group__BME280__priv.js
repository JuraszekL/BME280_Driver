var group__BME280__priv =
[
    [ "Macros", "group__BME280__privmacros.html", "group__BME280__privmacros" ],
    [ "Enums", "group__BME280__privenums.html", null ],
    [ "Functions", "group__BME280__privfunct.html", "group__BME280__privfunct" ],
    [ "adc_regs", "structadc__regs.html", [
      [ "hum_raw", "structadc__regs.html#a005eaf22ea98b6bfd7b260937d80ab47", null ],
      [ "press_raw", "structadc__regs.html#aba74d1d5786208d624a3b3d72604b672", null ],
      [ "temp_raw", "structadc__regs.html#ab8a25ff346327d061a9af66d56ab6e75", null ]
    ] ]
];