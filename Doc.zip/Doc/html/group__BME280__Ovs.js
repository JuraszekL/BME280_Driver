var group__BME280__Ovs =
[
    [ "BME280_OVERSAMPLING_SKIPP", "group__BME280__Ovs.html#ga507f651db356f3250fdb5fc3c1023a85", null ],
    [ "BME280_OVERSAMPLING_X1", "group__BME280__Ovs.html#ga82cab19a39d2a3e38c5d982e5f1e6116", null ],
    [ "BME280_OVERSAMPLING_X16", "group__BME280__Ovs.html#ga011b4e3ec4b2b56f313097a81f897d14", null ],
    [ "BME280_OVERSAMPLING_X2", "group__BME280__Ovs.html#ga1030a53c5c0bfb63406273a6f80a771f", null ],
    [ "BME280_OVERSAMPLING_X4", "group__BME280__Ovs.html#ga9e64bb7a92fc1a4b393828ead5ffdf17", null ],
    [ "BME280_OVERSAMPLING_X8", "group__BME280__Ovs.html#ga6fcf41ac56caa3dbd60ec9ecbb3e2edf", null ]
];