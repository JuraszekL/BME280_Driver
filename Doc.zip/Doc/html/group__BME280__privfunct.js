var group__BME280__privfunct =
[
    [ "bme280_busy_check", "group__BME280__privfunct.html#ga8343f635b75699deaa07427252889cfc", null ],
    [ "bme280_compensate_h_u32t", "group__BME280__privfunct.html#gac58949fad96ed5c847aa216db9c6d670", null ],
    [ "bme280_compensate_p_u32t", "group__BME280__privfunct.html#ga700ea2cbdda466bb7081442242ec76d0", null ],
    [ "bme280_compensate_t_s32t", "group__BME280__privfunct.html#gaedb94ae9df7b8661ff2cf90432b7a8eb", null ],
    [ "bme280_convert_h_U32_float", "group__BME280__privfunct.html#gaee6ee178feb26bfb8dc0dc6e2fb03ec0", null ],
    [ "bme280_convert_h_U32_struct", "group__BME280__privfunct.html#gab95b8d21c52e0b0d2e4777a9cd7d7b2d", null ],
    [ "bme280_convert_p_U32_float", "group__BME280__privfunct.html#gaccb2f1cfb71857f1b4a0fcacbaf89482", null ],
    [ "bme280_convert_p_U32_struct", "group__BME280__privfunct.html#ga232a14f7b8ce95a6361262d83d4b1f67", null ],
    [ "bme280_convert_t_S32_float", "group__BME280__privfunct.html#ga25397f1bedf6cd71109cdfd3f1183ab6", null ],
    [ "bme280_convert_t_S32_struct", "group__BME280__privfunct.html#ga12a4aad24d012cd3342321f94652d451", null ],
    [ "bme280_is_normal_mode", "group__BME280__privfunct.html#gab09542d9fbe46eb192c2dfccf8e39d9a", null ],
    [ "bme280_is_sleep_mode", "group__BME280__privfunct.html#ga1f4f109aa267eeadaebc6ad3480e82eb", null ],
    [ "bme280_osrs_to_oversampling", "group__BME280__privfunct.html#gac99cc1613153f309c690f9ab60672079", null ],
    [ "bme280_parse_hum_s32t", "group__BME280__privfunct.html#gabf6edac6fc9a92de861c8caab699e941", null ],
    [ "bme280_parse_press_temp_s32t", "group__BME280__privfunct.html#gacc6bfacd530167bee7ea999a7257927a", null ],
    [ "bme280_read_compensate", "group__BME280__privfunct.html#ga8feb22224ecaa8e66fff3db021bebeb4", null ],
    [ "bme280_read_compensation_parameters", "group__BME280__privfunct.html#gaa6b3e52e229e2ac9e57555a85f044234", null ],
    [ "bme280_set_forced_mode", "group__BME280__privfunct.html#gaf4bb61fd0d5fa3aa7e9cb66427cab79b", null ]
];