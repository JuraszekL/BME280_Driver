var structadc__regs =
[
    [ "hum_raw", "structadc__regs.html#a005eaf22ea98b6bfd7b260937d80ab47", null ],
    [ "press_raw", "structadc__regs.html#aba74d1d5786208d624a3b3d72604b672", null ],
    [ "temp_raw", "structadc__regs.html#ab8a25ff346327d061a9af66d56ab6e75", null ]
];