var group__BME280__setfunctions =
[
    [ "BME280_Disable3WireSPI", "group__BME280__setfunctions.html#gae11ebd6d7bd44d29029b38c9ed25c4f5", null ],
    [ "BME280_Enable3WireSPI", "group__BME280__setfunctions.html#ga3ee05f6cdc49f08360b7ddb23501c877", null ],
    [ "BME280_SetFilter", "group__BME280__setfunctions.html#ga5e945ae3a0ff27c3c3b4a0ebe5649404", null ],
    [ "BME280_SetHOvs", "group__BME280__setfunctions.html#gafd8641bfda9f876780a985a22d4e9f4e", null ],
    [ "BME280_SetMode", "group__BME280__setfunctions.html#ga3e0acbb8b2b084d390dbad162c16cd3c", null ],
    [ "BME280_SetPOvs", "group__BME280__setfunctions.html#ga18dc50119c4eaba4a541a0c252112c1b", null ],
    [ "BME280_SetTOvs", "group__BME280__setfunctions.html#gaaea37172f9ecfc23c2d1812813376ca4", null ],
    [ "BME280_SetTStby", "group__BME280__setfunctions.html#ga201381e8e1b2ec5500493eb27a3d5d9d", null ]
];