var structBME280__Data__t =
[
    [ "humidity_fract", "structBME280__Data__t.html#a771864c82755650ff065349ad8e32566", null ],
    [ "humidity_int", "structBME280__Data__t.html#a63391192ba51f5adb1f965b47c36cee4", null ],
    [ "pressure_fract", "structBME280__Data__t.html#a821651333917e627e48478426c8608a8", null ],
    [ "pressure_int", "structBME280__Data__t.html#ac40026df8b67c9d5801fa2f7ecabdc6d", null ],
    [ "temp_fract", "structBME280__Data__t.html#a58ec3ec9de3f7e1a1ce42f6991b9ca86", null ],
    [ "temp_int", "structBME280__Data__t.html#a98b2bcd3d256d15739f8b4ce696c398f", null ]
];