var group__BME280__getfunctions =
[
    [ "BME280_GetHOvs", "group__BME280__getfunctions.html#gab105f46ef83181777c044da90811d9af", null ],
    [ "BME280_GetMode", "group__BME280__getfunctions.html#gabac6aa8248a7a8505655960497fed56b", null ],
    [ "BME280_GetPOvs", "group__BME280__getfunctions.html#ga6bac94aca5f465eb65661482969692ae", null ],
    [ "BME280_GetTFilter", "group__BME280__getfunctions.html#ga5543c6d619ba917c7dac2cda0cafb08d", null ],
    [ "BME280_GetTOvs", "group__BME280__getfunctions.html#ga4c61f72e84a4f4ed90e46eeb11796f95", null ],
    [ "BME280_GetTStby", "group__BME280__getfunctions.html#gab215d4921f1604f9257e9ac7c2f67cd3", null ],
    [ "BME280_Is3WireSPIEnabled", "group__BME280__getfunctions.html#gad3f3110ddd3b0b848a336f502ede24e8", null ]
];