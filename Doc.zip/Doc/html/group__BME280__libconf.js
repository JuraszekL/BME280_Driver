var group__BME280__libconf =
[
    [ "USE_64BIT", "group__BME280__libconf.html#ga2cf2919ea2507e9d9cf2b329eac28be8", null ],
    [ "USE_FLOATS_RESULTS", "group__BME280__libconf.html#ga76bfb17ae3bd38938997b0e2d42e868d", null ],
    [ "USE_FORCED_MODE", "group__BME280__libconf.html#gafc0d86d413b4b82e63a137037bd14c76", null ],
    [ "USE_GETTERS", "group__BME280__libconf.html#gaa10db2f0d121e8249d7e24b2929bde92", null ],
    [ "USE_INTEGER_RESULTS", "group__BME280__libconf.html#ga92e7fcc6187945f9d8e26efd159073a7", null ],
    [ "USE_NORMAL_MODE", "group__BME280__libconf.html#ga9d07d0713356990b7bbacf48ba9e89da", null ],
    [ "USE_SETTERS", "group__BME280__libconf.html#gae9c33b7ded9b49f10c6293c986a00d1e", null ]
];