var group__BME280__I2CAddr =
[
    [ "BME280_I2CADDR_SDOH", "group__BME280__I2CAddr.html#ga2590a0f2babfb11e1b722deccd255657", null ],
    [ "BME280_I2CADDR_SDOL", "group__BME280__I2CAddr.html#ga0e1beac980e2c3e3d817a13038a7104f", null ]
];